window.COFFEE_CONFIG = {
	API_GW_BASE_URL_STR: "https://mw3wfpwujb.execute-api.us-east-1.amazonaws.com/prod",
	COGNITO_LOGIN_BASE_URL_STR: "https://299cc0c0.auth.us-east-1.amazoncognito.com/login?client_id=4gbcomn2evff9hh60r73va1t6v&response_type=token&scope=email+openid&redirect_uri=https://dqkrie0npl48d.cloudfront.net/callback.html"
};